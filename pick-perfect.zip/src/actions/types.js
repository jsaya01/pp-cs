/**
 * auth action types
 */

export const USER_SUCCESS = 'USER_SUCCESS';
export const USER_FAILURE = 'USER_FAILURE';


export const QUESTION_SUCCESS = 'QUESTION_SUCCESS';
export const QUESTION_FAILURE = 'QUESTION_FAILURE';
